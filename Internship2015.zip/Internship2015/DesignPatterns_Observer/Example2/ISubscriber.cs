﻿namespace DesignPatterns.Observer.Example2
{
    public interface ISubscriber
    {
        void Update(string video);
    }
}
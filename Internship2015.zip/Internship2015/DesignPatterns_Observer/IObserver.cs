﻿namespace DesignPatterns.Observer
{
    public interface IObserver
    {
        void Update(string state);
    }
}